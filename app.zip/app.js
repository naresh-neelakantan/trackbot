// This loads the environment variables from the .env file
//require('dotenv-extended').load();

var builder = require('botbuilder');
var restify = require('restify');
var database = require("./Database.js")
const env = require('dotenv');
env.config();

// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
    console.log('%s listening to %s', server.name, server.url);
});

// Create connector and listen for messages
var connector = new builder.ChatConnector({
    appId: process.env.MICROSOFT_APP_ID,
    appPassword: process.env.MICROSOFT_APP_PASSWORD
});

server.post('/api/messages', connector.listen());

var HelpMessage = '';
var UserNameKey = 'UserName';
var UserWelcomedKey = 'UserWelcomed';
// var urls = "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/8f41d0fb-d7f1-4f6f-87e4-d3ece31ba8c0?subscription-key=3576f9b91fdf4762b5a0dd790e68a1af&verbose=true&timezoneOffset=5.5&q=";
// var emailMessage ="-----Original Message----- From: ORD Dario Hernandez [mailto:dhernandez@worldcourier.com] Sent: Montag, 17. Juli 2017 16:32 To: WERNER, WILLIAM ; SLAVIC, ZEMKA SWISS ; SESTIC, MIRJANA ; MCREDMOND, DANIEL Cc: ORD Operations Subject: MAWB#724-61316824 JOB#4686 XPRESSO SERVICE Please provide us with a booking as per the following information: MAWB: 724-61316824 Pieces: 4 pieces Weight: 158.8 KGS Dims: 3 @ 33x18x19 IN & 1 @ 16x16x16 IN Commodity: RESEARCH SAMPLES / UN1845,DRY ICE,9 – 1 X 15 KGS & 3 X 30 KGS Routing: ORD – ZRH Flights: LX 009 / 17 JULY Service: XPRESSO Screened: YES If you need anything further, please feel free to contact us Dario Hernandez World Courier, an AmerisourceBergen company Operations Agent ORD 3737 N. 25th Avenue Schiller Park, IL, 60176 Tel: 1-630-694-9077 Fax: 1-630-694-9070 www.worldcourier.com _____ World Courier, Inc. Registered office: 1313 Fourth Avenue, New Hyde Park, New York, 11040, USA. This e-mail, including any attachments, may contain confidential and/or privileged information. It is for the sole use of the intended recipient. If you have received it in error, please notify the sender immediately and delete it from your system. Any unauthorised copying, disclosure, distribution, use or retention of this e-mail or the information in it is strictly forbidden. Please note we reserve the right to monitor all e-mail communication for quality assurance, policy compliance and/or security purposes. Play your part in saving the environment - please do not print this e-mail unless absolutely necessary "

// Setup bot with default dialog
var bot = new builder.UniversalBot(connector, [ 
    (session, next) => {

        // is user's name set? 
        var userName = session.userData[UserNameKey];
        if (!userName) {
            return session.beginDialog('greet');
        }
        // has the user been welcomed to the conversation?
        if (!session.privateConversationData[UserWelcomedKey]) {
            session.privateConversationData[UserWelcomedKey] = true;
            return session.send('Welcome to Swiss Cargo AWB/Flight search. Welcome back %s!  %s', userName, HelpMessage);
        }
        else {
            session.beginDialog('MainMethod');
        }
    }
]);

// LUIS
//Enable Conversation Data persistence
// var globalTunnel = require('global-tunnel');
// globalTunnel.initialize('http://10.6.13.87:8080', 8080);
var recognizer = new builder.LuisRecognizer(process.env.LUIS_MODEL_URL);
recognizer.onEnabled((context,callback)=>{
    if(context.dialogStack().length>0)
        callback(null,false);
    else
        callback(null,true);
});
bot.recognizer(recognizer);
// globalTunnel.end(); 

//Main Method
bot.dialog('MainMethod', [  
    (session, args) => 
    { 
        LuisAjax(session.message.text,session);
    }
]);

// Greet dialog
bot.dialog('greet', new builder.SimpleDialog(function (session, results) {
    if (results && results.response) {
        session.userData[UserNameKey] = results.response;
        session.privateConversationData[UserWelcomedKey] = true;
        var thumbnail = new builder.ThumbnailCard(session);
        thumbnail.title(results.response);
        thumbnail.images([builder.CardImage.create(session,"C:/Users/Public/Pictures/Sample Pictures/Desert.jpg")]);
        var text = '\n Company :Swiss Cargo \n Email :' + results.response + '@swisscargo.com';
        thumbnail.text(text);
        thumbnail.tap(new builder.CardAction.openUrl(session,"https://www.swissworldcargo.com/about_us/company/our_story"));
        var messagess = new builder.Message(session).attachments([thumbnail]);
        session.send(messagess);
        return session.endDialog('Welcome to Swiss Cargo AWB/Flight search.Welcome %s! %s', results.response, HelpMessage);
    }
    builder.Prompts.text(session, 'Before get started, please tell me your name?', {retryPrompt : "Please enter your Name..."});
}));

// AWB Search
bot.dialog('Note.Search', [  
    (session, args) => 
    {       
        session.sendTyping();
        var AWBNumber = args;

        var match = false;
        var userName = session.userData[UserNameKey];
        if(AWBNumber.length!=11)
            session.send('Invalid AWB Number format. Please enter valid AWB number in format 1XX-12XXXX78');
        else{
            database.awb.forEach(function(element) {
                if(element.key.toString()== AWBNumber){
                    //session.endDialogWithResult({response :element.value});
                    session.endConversation(element.value);
                    match = true;
                } 
            }, this);
        }
        if(!match) 
        session.send('AWB not found. Please enter AWB/Flight number');
    }
]).triggerAction({ matches: 'Note.Search' });

// Flight Search
bot.dialog('Note.Flight', [  
    (session, args) => 
    {       
        session.sendTyping();
        var FlightNumber = sargs;

        var match = false;
        var userName = session.userData[UserNameKey];
        if(FlightNumber.length>4)
            session.send('Invalid Flight Number format. Please enter valid Flight number upto 4 digit');
        else{
            database.flight.forEach(function(element) {
                if(element.key.toString()== FlightNumber){
                    //session.endDialogWithResult({response :element.value});
                    session.endConversation(element.value);
                    match = true;
                } 
            }, this);
        }
        if(!match) 
        session.send('Flight not found. Please enter valid Flight number');
    }
]).triggerAction({ matches: 'Note.Flight' });

function LuisAjax(statement,session){
    var HttpsProxyAgent = require('https-proxy-agent');  
    var request = require('request');  
    var proxy = 'http://10.6.13.87:8080';  
    var agent = new HttpsProxyAgent(proxy);  
    request({  
        uri: process.env.LUIS_MODEL_URL + statement,
        method: "GET",
        headers: {
            'content-type': 'application/json'
        },
        agent: agent,
        timeout: 10000,
        followRedirect: true,
        maxRedirects: 10
    }, function(error, response, body) {
        var luisresult = JSON.parse(body);
        if(luisresult.topScoringIntent.intent=='Note.Search'){
            var args = luisresult.entities[0].entity.replace(/\s/g, '');
            session.beginDialog('Note.Search',args);
        }
        else if(luisresult.topScoringIntent.intent=='Note.Flight'){
            var args = luisresult.entities[0].entity.replace(/\s/g, '');
            session.beginDialog('Note.Flight',args);
        }
        else if(luisresult.topScoringIntent.intent=='None'){
            session.send("Please enter AWB/Flight number to search");
            var thumbnail = new builder.ThumbnailCard(session);
            thumbnail.title("Swiss Cargo 'Contact US'");
            thumbnail.images([builder.CardImage.create(session,"C:/Users/Public/Pictures/Sample Pictures/Swiss.PNG")]);
            var text = '\n Please click here for any other queries';
            thumbnail.text(text);
            thumbnail.tap(new builder.CardAction.openUrl(session,"https://www.swissworldcargo.com/en/web/20184/station-info"));
            var messagess = new builder.Message(session).attachments([thumbnail]);
            session.send(messagess);
        }
    }); 
}


// (session, args, next) => 
// {   
//     var AWBNumber = session.message.text.match(/\d[\d\.]*/g);
//     if (AWBNumber == null)
//         session.send('Please enter AWB number');
//     else{
//         //const query = builder.EntityRecognizer.findEntity(session.message.text, 'awb');
//         session.privateConversationData["textsearch"] = session.message.text;
//         builder.Prompts.choice(
//             session,"Please confirm AWB number is correct?",
//             database.availableAWB,
//             { listStyle: builder.ListStyle.button }
//         )
//     }   
// },

// var regexp = require('node-regexp');
// var re = regexp()
// .either('airway','awb','bill','look for','find','search','help')
// .ignoreCase()
// .toRegExp()
// var boolval = re.test(statement);
//AWBNumber = statement.match(/\d[\d\.]*/g);


// reset bot dialog
// bot.dialog('reset', function (session) {
//     // reset data
//     delete session.userData[UserNameKey];
//     delete session.conversationData[CityKey];
//     delete session.privateConversationData[CityKey];
//     delete session.privateConversationData[UserWelcomedKey];
//     session.endDialog('Ups... I\'m suffering from a memory loss...');
// }).triggerAction({ matches: /^reset/i });