var awb = []; // create an empty array


awb.push(
{
    key:   "74312345678",
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"+417676767676",
    shipmentready:'18.11.2017 01:45',    
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"

},
{
    key:   "64312345678",
    shipmentready:'18.11.2017 01:45',
    Name: "Nils Fenner",
    EmailId: "nils@abb.ch",
    Company: "ABB",
    Mobile :"+416767676767",
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'5 Pieces',
    value: "Shipment Arrived"

},
{
    key:   "54312345678",
    shipmentready:'18.11.2017 01:45',
    Name: "Nils Fenner",
    EmailId: "nils@abb.ch",
    Company: "ABB",
    Mobile :"+416767676767",
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"
},
{
    key:   "44312345678",
    shipmentready:'18.11.2017 01:45',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767676",
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"
},
{
    key:   "34312345678",
    shipmentready:'18.11.2017 01:45',
    Name: "Christian Piguet",
    EmailId: "christian@csem.ch",
    Company: "CSEM",
    Mobile :"+417676767678",
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"
},
{
    key:   "24312345678",
    shipmentready:'18.11.2017 01:45',
    shipmentdeparted:'18.11.2017 07:45',
    Name: "Christian Piguet",
    EmailId: "christian@csem.ch",
    Company: "CSEM",
    Mobile :"+417676767678",
    flightdeparture:'18.11.2017 08:45',
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived on 13-Nov-2017 at 5.30 AM"
},
{
    key:   "14312345678",
    shipmentready:'18.11.2017 01:45',
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    Name: "Patrick Lambelet",
    EmailId: "patrick@heliotis.ch",
    Company: "Heliotis",
    Mobile :"+417676767679",
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'Yet to deliver',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"
},
{
    key:   "73312345678",
    shipmentready:'18.11.2017 01:45',
    shipmentdeparted:'18.11.2017 07:45',
    flightdeparture:'18.11.2017 08:45',
    Name: "Patrick Lambelet",
    EmailId: "patrick@heliotis.ch",
    Company: "Heliotis",
    Mobile :"+417676767679",
    FlightArrival :'18.11.2017 09:45',
    ShipmentArrived :'18.11.2017 10:10',   
    ShipmentReadyForPUp :'18.11.2017 10:45',
    ShipmentDelivered  :'18.11.2017 11:45',
    Itemcount :'1 Pieces',
    value: "Shipment Arrived"
},
{
    key:   "72312345678",
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    shipmentready:'18/11/2017',
    shipmentdeparted:'18/11/2017',
    flightdeparture:'18/11/2017',
    Itemcount :'1',
    value: "Shipment Arrived"
},
{
    key:   "71312345678",
    shipmentready:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    shipmentdeparted:'18/11/2017',
    flightdeparture:'18/11/2017',
    EmailId: "tes2t@gmail.com",
    Itemcount :'1',
    value: "Shipment Arrived"
},
{
    key:   "74212345678",
    shipmentready:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    shipmentdeparted:'18/11/2017',
    flightdeparture:'18/11/2017',
    
    Itemcount :'1',
    value: "Shipment Sent"
},
{
    key:   "74112345678",
    shipmentready:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    shipmentdeparted:'18/11/2017',
    EmailId: "tes2t@gmail.com",
    flightdeparture:'18/11/2017',
    Itemcount :'1',
    value: "Shipment Arrived"
},
{
    key:   "74312345668",
    shipmentready:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    shipmentdeparted:'18/11/2017',
    flightdeparture:'18/11/2017',
    EmailId: "tes2t@gmail.com",
    Itemcount :'1',
    value: "Shipment Arriving"
},
{
    key:   "74312345658",
    shipmentready:'18/11/2017',
    shipmentdeparted:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    flightdeparture:'18/11/2017',
    Itemcount :'1',
    value: "Shipment Sent"
},
{
    key:   "74323456789",
    shipmentready:'18/11/2017',
    shipmentdeparted:'18/11/2017',
    Name: "Eva Goldschmidt",
    EmailId: "eva@roche.ch",
    Company: "Roche Diagnostics",
    Mobile :"7676767678",
    flightdeparture:'18/11/2017',
    Itemcount :'1',
    value: "Shipment Sent"
});   

var flight = []; // create an empty array
flight.push(
{
    key:   "lx1266",
    EmailId: "tes2t@gmail.com",
    value: "Zurich (Kloten) to Copenhagen ETA - Wed 08:49 CET "
},
{
    key:   "lx1325",
    EmailId: "tes2t@gmail.com",
    value: "Domodedovo Int'l to Zurich (Kloten) ETA - Wed 10:28 CET"
}); 

// var availableAWB=[];
// availableAWB.push("Yes");
// availableAWB.push("No");

exports.awb = awb;
exports.flight = flight;
// exports.availableAWB = availableAWB;